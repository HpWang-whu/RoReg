Miscellaneous Classes
=====================

Kernel Generator
----------------

.. autoclass:: MinkowskiEngine.KernelGenerator
    :members:
    :undoc-members:

    .. automethod:: __init__


RegionType
----------

.. autoclass:: MinkowskiEngine.RegionType
    :members:
    :undoc-members:
